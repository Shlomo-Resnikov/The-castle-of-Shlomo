//
//  ViewController.swift
//  Calculator
//
//  Created by Telekomlab7 on 27.11.20.
//  Copyright © 2020 KevinFaggioli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNumber: UITextField!
    @IBOutlet weak var secondnumber: UITextField!
    @IBOutlet weak var apeearinganswer: UILabel!
    
   
    @IBOutlet weak var progress: UIProgressView!
    
    @IBOutlet weak var signs: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func Calculation(_ sender: Any) {
        var firstValue = Int(firstNumber.text!)
        var secondValue = Int(secondnumber.text!)
        var result = firstValue! + secondValue!;        if(signs.selectedSegmentIndex == 0)
        {
            result=firstValue! + secondValue!
            
        }
        else
       {
        result=firstValue! - secondValue!
        }
      
        self.progress.setProgress(0.5, animated: true)
        self.apeearinganswer.text = String(result)
}
}

    


